package com.thacker.finalprojectcalculator;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.os.Handler;
import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity implements OnClickListener {

   public void check(){
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                openDatabase();
            }
        }, 2000);   //2 seconds
    }
    float Input;
    float Input2;
    float Result;
    String ResultTextString;
    private Button Switch;
    private Button Addition;
    private Button Multiplication;
    private Button Subtraction;
    private Button Division;
    private Button Mean;
    private EditText InputText;
    private EditText InputAltText;
    private TextView ResultText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Switch = (Button) findViewById(R.id.buttonSwitch);
        Addition = (Button) findViewById(R.id.buttonAddition);
        Multiplication = (Button) findViewById(R.id.buttonMultiplication);
        Subtraction = (Button) findViewById(R.id.buttonSubtraction);
        Division = (Button) findViewById(R.id.buttonDivision);
        Mean = (Button) findViewById(R.id.buttonMean);

        InputText = (EditText) findViewById(R.id.editTextCalculator);
        InputAltText = (EditText) findViewById(R.id.editTextCalculator2);
        ResultText = (TextView) findViewById(R.id.textViewResult);

        Addition.setOnClickListener(this);
        Multiplication.setOnClickListener(this);
        Subtraction.setOnClickListener(this);
        Division.setOnClickListener(this);
        Mean.setOnClickListener(this);
        Switch.setOnClickListener(this);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.buttonAddition:
                Input = Float.valueOf(InputText.getText().toString());
                Input2 = Float.valueOf(InputAltText.getText().toString());
                try{
                Result = Input + Input2;
                ResultTextString = String.valueOf(Result);
                ResultText.setText(ResultTextString);
                }
                catch(Exception e){
                    Toast.makeText(getApplicationContext(),"Check inputs.",Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.buttonSubtraction:
                Input = Float.valueOf(InputText.getText().toString());
                Input2 = Float.valueOf(InputAltText.getText().toString());
                try{
                    Result = Input - Input2;
                    ResultTextString = String.valueOf(Result);
                    ResultText.setText(ResultTextString);
                }
                catch(Exception e){
                    Toast.makeText(getApplicationContext(),"Check inputs.",Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.buttonMultiplication:
                Input = Float.valueOf(InputText.getText().toString());
                Input2 = Float.valueOf(InputAltText.getText().toString());
                try{
                    Result = Input * Input2;
                    ResultTextString = String.valueOf(Result);
                    ResultText.setText(ResultTextString);
                }
                catch(Exception e){
                    Toast.makeText(getApplicationContext(),"Check inputs.",Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.buttonDivision:
                Input = Float.valueOf(InputText.getText().toString());
                Input2 = Float.valueOf(InputAltText.getText().toString());
                try{
                    Result = Input / Input2;
                    ResultTextString = String.valueOf(Result);
                    ResultText.setText(ResultTextString);
                }
                catch(Exception e){
                    Toast.makeText(getApplicationContext(),"Check inputs.",Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.buttonMean:
                Input = Float.valueOf(InputText.getText().toString());
                Input2 = Float.valueOf(InputAltText.getText().toString());
                try{
                    Result = (Input + Input2)/2;
                    ResultTextString = String.valueOf(Result);
                    ResultText.setText(ResultTextString);
                }
                catch(Exception e){
                    Toast.makeText(getApplicationContext(),"Check inputs.",Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.buttonSwitch:
                 check();
        }
    }
        public void openDatabase(){
            Intent DatabaseIntent = new Intent(MainActivity.this, Database.class);
            String message = "It'll all be good";
            DatabaseIntent.putExtra("message", message);
             startActivity(DatabaseIntent);
        }
}
